<?php 

$email_adm = 'karinanerisantos@gmail.com';
$url_site = 'http://localhost/admchurch/';


//DADOS PARA CONEXÃO COM BD LOCAL
$banco = 'admchurch';
$host = 'localhost';
$usuario = 'root';
$senha = '';

$itens_por_pagina = 5;

$itens_por_pagina_1 = 5;
$itens_por_pagina_2 = 10;
$itens_por_pagina_3 = 20;
 ?>