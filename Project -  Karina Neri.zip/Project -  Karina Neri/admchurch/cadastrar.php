<?php 

include_once("conexao.php");

$nome = $_POST['nome'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$nomeigreja = $_POST['nomeigreja'];
$senha = $_POST['senha'];
$confirm = $_POST['confirm'];

if($senha != $confirm){
  echo 'As senhas informadas não coincidem!';
  exit();
}


$res = $pdo->query("SELECT * from usuario where email = '$email'");
$dados = $res->fetchAll(PDO::FETCH_ASSOC);
$linhas = count($dados);
if($linhas > 0){
    $email_recup = $dados[0]['email'];
}

if($email == @$email_recup){
    echo 'E-mail já Cadastrado!';
    exit();
}




$res = $pdo->prepare("INSERT into usuario (nome, email, telefone, nomeigreja, senha, confirm) values (:nome, :email, :telefone, :nomeigreja, :senha, :confirm)");

    $res->bindValue(":nome", $nome);
    $res->bindValue(":email", $email);
    $res->bindValue(":telefone", $telefone);
    $res->bindValue(":nomeigreja", $nomeigreja);
    $res->bindValue(":senha", $senha);
    $res->bindValue(":confirm", $confirm);

    $res->execute();

echo 'Cadastrado com Sucesso!!';

 ?>