<?php 

include_once("conexao.php");?>
<head>
  <title>Login</title>
  <link rel="icon" href="images/favicon.png" type="image/x-icon">
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <link rel="stylesheet" href="css/login.css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>


<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  <!------ Include the above in your HEAD tag ---------->
</head>
<!-- login start -->

<body>

  <div class="wrapper fadeInDown">
    <div id="formContent">
      <!-- Tabs Titles -->

      <!-- Icon -->
      <a class="fadeIn first" href="index.php">
        <img src="images/logo-default-480x80.png"  id="icon" alt="Icon"  />
      </a>

      <!-- Login Form -->
      <form class="login100-form validate-form" method="post" action="autenticar.php">
        <input type="text" id="email" class="fadeIn second" name="email" placeholder="e-mail" required>
        <input type="password" id="senha" class="fadeIn third" name="senha" placeholder="senha" required>
        <input type="submit" class="fadeIn fourth" value="Logar">
      </form>

      <div id="formFooter">
        <a class="underlineHover"  href="" data-toggle="modal" data-target="#modal-rec">Recuperar Senha</a>
      </div>
      <div id="formFooter">Não tem Cadastro?
        <a class="underlineHover" href="cadastro.php">Cadastre-se</a>
      </div>

    </div>

  </div>

</body>


<div class="modal fade" id="modal-rec" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" style= "color:#0d5940;">Recuperar Senha</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post">

          <div class="form-group">
            <input type="email" class="form-control" id="email-recuperar" name="email-recuperar"  placeholder="Email" required>

          </div>




          <div align="center" class="" id="mensagem2">
          </div>


        </div>
        <div class="modal-footer">
         <button type="button" id="btn-fechar" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
         <button name="btn-rec" id="btn-rec" class="btn btn-info" style= "background-color:#1ab785;">Recuperar</button>

       </form>

     </div>
   </div>
 </div>
</div>



<script> $("#modal-login").modal("show"); </script> 

<!--AJAX PARA RECUPERAR A SENHA -->
<script type="text/javascript">
  $(document).ready(function(){

    $('#btn-rec').click(function(event){
      event.preventDefault();

      $.ajax({
        url: "recuperar.php",
        method: "post",
        data: $('form').serialize(),
        dataType: "text",
        success: function(mensagem){

          $('#mensagem2').removeClass()

          if(mensagem == 'Senha enviada para o seu Email!'){

            $('#mensagem2').addClass('text-success')

  


            $('#email-recuperar').val('')


                    //$('#btn-fechar').click();
                    //location.reload();



                  }else{

                    $('#mensagem2').addClass('text-danger')
                  }

                  $('#mensagem2').text(mensagem)

                },

              })
    })
  })
</script>





