<?php
require_once("../../conexao.php");
$pagina = 'ofertas';
$id = @$_POST['id-excluir'];


$query = $pdo->query("DELETE FROM $pagina where id = '$id'");
$query = $pdo->query("DELETE FROM movimentacoes where id_mov = '$id' and movimento = 'Oferta'");

echo 'Excluído com Sucesso';
?>