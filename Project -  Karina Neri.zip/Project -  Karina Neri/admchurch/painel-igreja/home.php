<?php 
require_once("../conexao.php");

@session_start();
$nivel_usu = @$_SESSION['nivel_usuario'];




$membrosCadastrados = 0;
$totalOfertas = 0;
$totalGastos = 0;
$totalDoacoes = 0;
$saldoMes = 0;

$pagarVencidas = 0;
$pagarHoje = 0;
$receberHoje = 0;

$query = $pdo->query("SELECT * FROM membresia where igreja = '$id_igreja' and ativo = 'Sim'");
$res = $query->fetchAll(PDO::FETCH_ASSOC);
$membrosCadastrados = @count($res);

$query = $pdo->query("SELECT * FROM pagar where descricao and vencimento = curDate() and pago != 'Sim'");
$res = $query->fetchAll(PDO::FETCH_ASSOC);
$pagarHoje = @count($res);

$query = $pdo->query("SELECT * FROM receber where usuario = '$id_usuario'  and vencimento = curDate() and pago != 'Sim'");
$res = $query->fetchAll(PDO::FETCH_ASSOC);
$receberHoje = @count($res);

$query = $pdo->query("SELECT * FROM pagar where usuario = '$id_usuario'  and vencimento < curDate() and pago != 'Sim'");
$res = $query->fetchAll(PDO::FETCH_ASSOC);
$pagarVencidas = @count($res);


$mes_atual = Date('m');
$ano_atual = Date('Y');
$dataInicioMes = $ano_atual."-".$mes_atual."-01";


$query = $pdo->query("SELECT * FROM movimentacoes where usuario = '$id_usuario' and data >= '$dataInicioMes' and data <= curDate()");
$res = $query->fetchAll(PDO::FETCH_ASSOC);
$total_reg = @count($res);
if($total_reg > 0){
	for($i=0; $i < $total_reg; $i++){
		foreach ($res[$i] as $key => $value){} 
			$tipo = $res[$i]['tipo'];
		$movimento = $res[$i]['movimento'];

		if($tipo == 'Saída'){
			$totalGastos += $res[$i]['valor'];
		}


		if($movimento == 'Oferta'){
			$totalOfertas += $res[$i]['valor'];
		}

		if($movimento == 'Doação'){
			$totalDoacoes += $res[$i]['valor'];
		}

	}
}

$saldoMes =  + $totalOfertas + + $totalDoacoes - $totalGastos;
if($saldoMes < 0){
	$classeSaldo = 'text-danger';
}else{
	$classeSaldo = 'text-success';
}

$totalGastos = number_format($totalGastos, 2, ',', '.');
$totalOfertas = number_format($totalOfertas, 2, ',', '.');
$totalDoacoes = number_format($totalDoacoes, 2, ',', '.');
$saldoMes = number_format($saldoMes, 2, ',', '.');

?>


<div class="container-fluid " >
	<section id="minimal-statistics" style="margin-right:20px">
		<div class="row mb-2">
			<div class="col-10 mt-3 mb-1">
				<h4 class="text-uppercase textocinzaescuro"><small><small></small></small></h4>

			</div>

			<div class="col-2 mt-3 mb-1" align="right">
				<small>Saldo Mês : <span class="<?php echo $classeSaldo ?>">R$ <?php echo $saldoMes ?></span></small>
			</div>
		</div>




		<div class="row mb-4">



			


			<div class="col-xl-3 col-sm-6 col-12 linkcard mb-2"> 
				<a href="index.php?pag=membresia">
					<div class="card">
						<div class="card-content">
							<div class="card-body">
								<div class="row">
									<div class="align-self-center col-3">
										<i class="bi bi-cash text-primary fs-1 float-start"></i>
									</div>
									<div class="col-9 text-end">
										<h3> <span class="text-primary">R$ <?php echo @$totalOfertas ?></span></h3>
										<span class="textocinzaescuro">Ofertas do Mês</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</a>
			</div>


			<div class="col-xl-3 col-sm-6 col-12 linkcard mb-2"> 
				<a href="index.php?pag=membresia">
					<div class="card">
						<div class="card-content">
							<div class="card-body">
								<div class="row">
									<div class="align-self-center col-3">
										<i class="bi bi-currency-dollar text-danger fs-1 float-start"></i>
									</div>
									<div class="col-9 text-end">
										<h3> <span class="text-danger">R$ <?php echo @$totalGastos ?></span></h3>
										<span class="textocinzaescuro">Gastos do Mês</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</a>
			</div>





			<div class="col-xl-3 col-sm-6 col-12 linkcard mb-2"> 
				<a href="index.php?pag=membresia">
					<div class="card">
						<div class="card-content">
							<div class="card-body">
								<div class="row">
									<div class="align-self-center col-3">
										<i class="bi bi-cash text-primary fs-1 float-start"></i>
									</div>
									<div class="col-9 text-end">
										<h3> <span class="text-primary">R$ <?php echo @$totalDoacoes ?></span></h3>
										<span class="textocinzaescuro">Doações do Mês</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</a>
			</div>




			<div class="col-xl-3 col-sm-6 col-12 mb-2 linkcard "> 
				<a href="index.php?pag=membresia">
					<div class="card">
						<div class="card-content">
							<div class="card-body">
								<div class="row">
									<div class="align-self-center col-3">
										<i class="bi bi-people-fill text-secondary fs-1 float-start"></i>
									</div>
									<div class="col-9 text-end">
										<h3> <span class="text-secondary"><?php echo @$membrosCadastrados ?></span></h3>
										<span class="textocinzaescuro">Total de Membros</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</a>
			</div>








			<div class="col-xl-3 col-sm-6 col-12 mb-2 linkcard "> 
				<a href="index.php?pag=membresia">
					<div class="card">
						<div class="card-content">
							<div class="card-body">
								<div class="row">
									<div class="align-self-center col-3">
										<i class="bi bi-calendar-week text-warning fs-1 float-start"></i>
									</div>
									<div class="col-9 text-end">
										<h3> <span class="text-warning"><?php echo @$pagarHoje ?></span></h3>
										<span class="textocinzaescuro">Contas à Pagar Hoje</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</a>
			</div>




			<div class="col-xl-3 col-sm-6 col-12 mb-2 linkcard "> 
				<a href="index.php?pag=membresia">
					<div class="card">
						<div class="card-content">
							<div class="card-body">
								<div class="row">
									<div class="align-self-center col-3">
										<i class="bi bi-calendar-week text-danger fs-1 float-start"></i>
									</div>
									<div class="col-9 text-end">
										<h3> <span class="text-danger"><?php echo @$pagarVencidas ?></span></h3>
										<span class="textocinzaescuro">Contas à Pagar Vencidas</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</a>
			</div>

			<div class="" align="right"><a href="index.php?mostrar=<?php echo $mostrar ?>" class="text-dark"><i class="bi <?php echo $icone_plus ?>"></i></a></div>

		</div>

	</section>

	<?php 
	$query = $pdo->query("SELECT * FROM agendda where status = 'Agendada' and igreja = '$id_igreja' order by status asc, data asc, hora asc LIMIT $quantidade_eventos");
	$res = $query->fetchAll(PDO::FETCH_ASSOC);
	$total_reg = count($res);
	?>

	<hr> 

	<div class="row" style="margin-right:10px">

		<?php 


		if($total_reg > 0){
			for($i=0; $i < $total_reg; $i++){
				foreach ($res[$i] as $key => $value){} 

					$titulo = $res[$i]['titulo'];	
				$data = $res[$i]['data'];
				$hora = $res[$i]['hora'];
				$descricao = $res[$i]['descricao'];
				$status = $res[$i]['status'];

				$id = $res[$i]['id'];

				$dataF = implode('/', array_reverse(explode('-', $data)));


				if($data < $data_atual || $hora < $hora_atual){
					$classe_icon = 'text-danger';
					$borda_card = 'bordacardsede';
				}else{
					$classe_icon = 'text-primary';
					$borda_card = 'bordacardtarefa';
				}


				?>

				<div class="col-xl-3 col-md-6 col-12 mb-4 linkcard">
					<a href="index.php?pag=tarefas">
						<div class="card text-danger shadow h-100 <?php echo $borda_card ?>">
							<div class="card-body">
								<div class="row no-gutters align-items-center">
									<div class="col mr-2">
										<div class="text-xs font-weight-bold text-primary text-uppercase titulocard"><?php echo $dataF ?></div>
										<div class="text-xs font-weight-bold text-danger text-uppercase titulocard"><?php echo $titulo ?></div>
										<div class="text-xs text-secondary subtitulocard"><?php echo$descricao ?> </div>
									</div>
									<div class="col-auto" align="center">
										<h2 style="margin:1px" class="bi bi-calendar2-check <?php echo $classe_icon ?>"></h2>
										<span class="text-xs totaiscard text-danger"><?php echo $hora ?></span>
									</div>
								</div>
							</div>
						</div>
					</a>
				</div>



			<?php } }else{
				echo '<small>Não existem eventos agendados!!</small>';
			} ?>

		</div>
	</div>