<?php 
require_once("../conexao.php");
require_once("verificar.php");
$pagina = 'patrimonios';
?>

<div class="row my-3" style="margin-right:20px">
	<div class="col-md-2">
		<a href="#" onclick="inserir()" type="button" class="btn btn-dark btn-sm">+ Novo Item</a>
	</div>
</div>

<div class="tabela bg-light">
	<?php 

	$query = $pdo->query("SELECT * FROM $pagina where usuario_cad = '$id_usuario'  order by id desc");
	$res = $query->fetchAll(PDO::FETCH_ASSOC);
	$total_reg = count($res);
	if($total_reg > 0){

		?>

		<table id="example" class="table table-striped table-light table-hover my-4 my-4" style="width:100%">
			<thead>			
				<tr>
					<th>Código</th>
					<th>Nome</th>
					<th>Descrição</th>
					<th>Estado de Conservação</th>
					<th class="esc">Cadastrado Por</th>
					<th class="esc">Data Cadastro</th>
					<th class="esc">Valor</th>
					<th class="esc">Foto</th>
					<th class="d-none">Ativo</th>					
					<th>Ações</th>
				</tr>		
			</thead>
			<tbody>
				<?php 
				for($i=0; $i < $total_reg; $i++){
					foreach ($res[$i] as $key => $value){} 

						$nome = $res[$i]['nome'];
					$codigo = $res[$i]['codigo'];
					$descricao = $res[$i]['descricao'];
					$estadocons = $res[$i]['estadocons'];
					$valor = $res[$i]['valor'];
					$usuario_cad = $res[$i]['usuario_cad'];
					$foto = $res[$i]['foto'];
					$data_cad = $res[$i]['data_cad'];
					$obs = $res[$i]['obs'];
					$ativo = $res[$i]['ativo'];
					$entrada = $res[$i]['entrada'];
					$doador = $res[$i]['doador'];
					$id = $res[$i]['id'];




					if($obs != ""){
						$classe_obs = 'text-warning';
					}else{
						$classe_obs = 'text-secondary';
					}


					if($ativo == 'Sim'){
						$classe = 'text-success';
						$ativo = 'Desativar Item';
						$icone = 'bi-check-square';
						$ativar = 'Não';
						$inativa = '';
						$tab = 'Ativo';

					}else{
						$classe = 'text-danger';
						$ativo = 'Ativar Item';
						$icone = 'bi-square';
						$ativar = 'Sim';
						$inativa = 'text-muted';
						$tab = 'Inativo';
					}

					$query_con = $pdo->query("SELECT * FROM usuario where id = '$usuario_cad'");
					$res_con = $query_con->fetchAll(PDO::FETCH_ASSOC);
					if(count($res_con) > 0){
						$nome_usu_cad = $res_con[0]['nome'];
					}else{
						$nome_usu_cad = '';
					}


					


				


					


					//retirar quebra de texto do obs
					$obs = str_replace(array("\n", "\r"), ' + ', $obs);

					$data_cadF = implode('/', array_reverse(explode('-', $data_cad)));
					$valorF = number_format($valor, 2, ',', '.');
					?>	
					<tr >							

					<td><?php echo $codigo ?></td>
						<td><?php echo $nome ?></td>
						<td><?php echo $descricao?></td>
						<td><?php echo $estadocons ?></td>
						<td class="esc"><?php echo $nome_usu_cad ?></td>
						<td class="esc"><?php echo $data_cadF ?></td>
						<td class="esc"><?php echo $valorF ?></td>
						
						<td class="esc"><img src="../images/patrimonios/<?php echo $foto ?>" width="30px"></td>

						<td class="d-none"><?php echo $tab ?></td>
						
						<td>
							<big>
								<a href="#" onclick="editar('<?php echo $id ?>', '<?php echo $codigo ?>', '<?php echo $nome ?>', '<?php echo $descricao ?>','<?php echo $estadocons?>', '<?php echo $valor ?>', '<?php echo $foto ?>', '<?php echo $data_cad ?>', '<?php echo $entrada ?>', '<?php echo $doador ?>')" title="Editar Registro">	<i class="bi bi-pencil-square text-primary"></i> </a>


								
								<a href="#" onclick="excluir('<?php echo $id ?>' , '<?php echo $nome ?>')" title="Excluir Registro">	<i class="bi bi-trash text-danger"></i> </a>

							<a href="#" onclick="dados('<?php echo $codigo ?>', '<?php echo $nome ?>', '<?php echo $descricao ?>','<?php echo $estadocons?>', '<?php echo $valor ?>', '<?php echo $foto ?>', '<?php echo $nome_usu_cad ?>', '<?php echo $data_cadF ?>', '<?php echo $obs ?>', '<?php echo $entrada ?>', '<?php echo $doador ?>')" title="Ver Dados">	<i class="bi bi-info-square-fill text-primary"></i> </a>

							<a href="#" onclick="obs('<?php echo $id ?>','<?php echo $nome ?>', '<?php echo $obs ?>')" title="Observações">	<i class="bi bi-chat-right-text text-secondary"></i> </a>



								<a href="#" onclick="mudarStatus('<?php echo $id ?>', '<?php echo $ativar ?>')" title="<?php echo $ativo ?>">
									<i class="bi <?php echo $icone ?> <?php echo $classe ?>"></i></a>



								</big>

							</td>
						</tr>	
					<?php } ?>	
				</tbody>
			</table>
		<?php }else{
			echo 'Não Existem Dados Cadastrados';
		} ?>
	</div>


	<div class="modal fade" id="modalForm" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="tituloModal"></h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<form id="form" method="post">
					<div class="modal-body">
						<div class="row">
							<div class="col-md-3">
								<div class="mb-3">
									<label for="exampleFormControlInput1" class="form-label">Código</label>
									<input type="text" class="form-control" id="codigo" name="codigo" placeholder="Código do item"  required>
								</div>
							</div>
							<div class="col-md-6">
								<div class="mb-3">
									<label for="exampleFormControlInput1" class="form-label">Nome</label>
									<input type="text" class="form-control" id="nome" name="nome" placeholder="Insira o Nome"  required>
								</div>
							</div>

							<div class="col-md-3">
								<div class="mb-3">
									<label for="exampleFormControlInput1" class="form-label">Data Cadastro</label>
									<input type="date" class="form-control" id="data_cad" name="data_cad" value="<?php echo date('Y-m-d') ?>" required>
								</div>
							</div>


						</div>

						<div class="mb-3">
							<label for="exampleFormControlInput1" class="form-label">Descrição Item</label>
							<input type="text" class="form-control" id="descricao" name="descricao" placeholder="Descrição do Item">
						</div>

						<div class="row">

							<div class="col-md-4">
								<div class="mb-3">

						<label for="exampleFormControlInput1" class="form-label">Estado de Conservação</label>
									<select class="form-select" aria-label="Default select example" name="estadocons" id="estadocons">  
										<option value="Péssimo">Péssimo</option>
										<option value="	Ruim">Ruim</option>
										<option value="Bom">Bom</option>
										<option value="Ótimo">Ótimo</option>

									</select>
								</div>
							</div>


						<div class="row">

							<div class="col-md-4">
								<div class="mb-3">
									<label for="exampleFormControlInput1" class="form-label">Entrada (Compra / Doação)</label>
									<select class="form-select" aria-label="Default select example" name="entrada" id="entrada">  
										<option value="Compra">Compra</option>
										<option value="Doação">Doação</option>

									</select>
								</div>
							</div>

							<div class="col-md-4">
								<div class="mb-3">
									<label for="exampleFormControlInput1" class="form-label">Valor</label>
									<input type="text" class="form-control" id="valor" name="valor" placeholder="Valor em caso de compra">
								</div>
							</div>

							<div class="col-md-4">
								<div class="mb-3">
									<label for="exampleFormControlInput1" class="form-label">Doador Por</label>
									<input type="text" class="form-control" id="doador" name="doador" placeholder="Nome do Doador">
								</div>
							</div>



						</div>

						<div class="row">

							<div class="col-md-5">
								<div class="mb-3">
									<label for="exampleFormControlInput1" class="form-label">Foto</label>
									<input type="file" class="form-control-file" id="imagem" name="imagem" onChange="carregarImg();">
								</div>
							</div>
							<div class="col-md-2">
								<div id="divImg" class="mt-4">
									<img src="../images/patrimonios/sem-foto.jpg"  width="100px" id="target">									
								</div>
							</div>

							

						</div>




					</div>
					<small><div align="center" id="mensagem"></div></small>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="btn-fechar">Fechar</button>
						<button type="submit" class="btn btn-primary">Salvar</button>
					</div>
				</form>
			</div>
		</div>
	</div>





	<!-- Modal -->
	<!-- Modal -->
	


	<div class="modal fade" id="modalDados" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Nome : <span id="nome-dados"></span></h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>

				<div class="modal-body">
					<small>
					<div class="row">
						<div class="col-md-6">
							<span class=""><b>Código:</b> <span id="codigo-dados"></span></span>
							
						</div>

						<div class="col-md-6">
							<span class=""><b>Descrição:</b> <span id="descricao-dados"></span></span>
							
						</div>
					</div>
					<hr style="margin:4px">

					<div class="col-md-6">
							<span class=""><b>Estado de Conservação:</b> <span id="estadocons-dados"></span></span>
							
						</div>
					</div>
					<hr style="margin:4px">

					<div class="row">
						<div class="col-md-6">
							<span class=""><b>Valor:</b> R$ <span id="valor-dados"></span></span>
							
						</div>

						<div class="col-md-6">

							<span class=""><b>Cadastrado Por:</b> <span id="usuario-cad-dados"></span></span>
							
						</div>
					</div>
					<hr style="margin:4px">


					<div class="row">
						<div class="col-md-6">
							<span class=""><b>Data de Cadastro:</b> <span id="data-cad-dados"></span></span>
						</div>

					</div>
					<hr style="margin:4px">



					<div class="row">

						<div class="col-md-6">

							<span class=""><b>Status do Item:</b> <span id="ativo-dados"></span></span>
						</div>
					</div>
					<hr style="margin:4px">


					<div class="row">
						<div class="col-md-6">
							<span class=""><b>Compra / Doação:</b> <span id="entrada-dados"></span></span>
						</div>

						<div class="col-md-6">

							<span class=""><b>Doador Por:</b> <span id="doador-dados"></span></span>
						</div>
					</div>
					<hr style="margin:4px">


					<div class="row">
						<div class="col-md-6">
							<span class=""><b>OBS:</b> <span id="obs-dados"></span></span>
						</div>

						<div class="col-md-6">

							<span class=""><img src="" id="foto-dados" width="170px"></span>
						</div>
					</div>
					<hr style="margin:4px">

			</small>
				</div>

			</form>
		</div>
	</div>
</div>





<div class="modal fade" id="modalExcluir" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel"><span id="tituloModal">Excluir Registro</span></h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<form id="form-excluir" method="post">
					<div class="modal-body">

						Deseja Realmente excluir este Registro: <span id="nome-excluido"></span>?

						<small><div id="mensagem-excluir" align="center"></div></small>

						<input type="hidden" class="form-control" name="id-excluir"  id="id-excluir">


					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="btn-fechar-excluir">Fechar</button>
						<button type="submit" class="btn btn-danger">Excluir</button>
					</div>
				</form>
			</div>
		</div>
	</div>





<!-- Modal -->
<div class="modal fade" id="modalObs" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel"><span id="tituloModal">Observações - <span id="nome-obs"></span></span></h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<form id="form-obs" method="post">
				<div class="modal-body">

					<div class="mb-3">
						<label for="exampleFormControlInput1" class="form-label">Observações (Máximo 1000 Caracteres)</label>
						<textarea class="form-control" id="obs" name="obs" maxlength="500" style="height:200px"></textarea>
					</div>



					<small><div id="mensagem-obs" align="center"></div></small>

					<input type="hidden" class="form-control" name="id-obs"  id="id-obs">


				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="btn-fechar-obs">Fechar</button>
					<button type="submit" class="btn btn-primary">Salvar</button>
				</div>
			</form>
		</div>
	</div>
</div>












		<script type="text/javascript">var pag = "<?=$pagina?>"</script>
		<script src="../js/ajax.js"></script>


		<script type="text/javascript">

			function editar(id, codigo, nome, descricao, estadocons, valor, foto, data_cad, entrada, doador){
				$('#id').val(id);
				$('#nome').val(nome);
				$('#codigo').val(codigo);
				$('#descricao').val(descricao);
				$('#estadocons').val(estadocons);
				$('#valor').val(valor);
				$('#data_cad').val(data_cad);
				$('#doador').val(doador);
				$('#entrada').val(entrada).change();
				$('#target').attr('src', '../images/patrimonios/' + foto);

				$('#tituloModal').text('Editar Registro');
				var myModal = new bootstrap.Modal(document.getElementById('modalForm'), {		});
				myModal.show();
				$('#mensagem').text('');
			}




			function dados(codigo, nome, descricao, estadocons, valor, foto, usuario_cad, data_cad, ativo, obs, entrada, doador)
				{}

				$('#nome-dados').text(nome);
				$('#descricao-dados').text(descricao);
								$('#estadocons').val(estadocons);
				$('#codigo-dados').text(codigo);
				$('#valor-dados').text(valor);
				$('#usuario-cad-dados').text(usuario_cad);
				$('#data-cad-dados').text(data_cad);
				$('#ativo-dados').text(ativo);
				$('#obs-dados').text(obs);
				$('#entrada-dados').text(entrada);
				$('#doador-dados').text(doador);
				$('#foto-dados').attr('src', '../images/patrimonios/' + foto);


				var myModal = new bootstrap.Modal(document.getElementById('modalDados'), {		});
				myModal.show();
				$('#mensagem').text('');
			}



			function obs(id, nome, obs){
				console.log(obs)

				for (let letra of obs){  				
					if (letra === '+'){
						obs = obs.replace(' +  + ', '\n')
					}			
				}


				$('#nome-obs').text(nome);
				$('#id-obs').val(id);
				$('#obs').val(obs);



				var myModal = new bootstrap.Modal(document.getElementById('modalObs'), {		});
				myModal.show();
				$('#mensagem-obs').text('');
			}

			function limpar(){
				var data = "<?=$data_atual?>";

				$('#id').val('');
				$('#nome').val('');		
				$('#descricao').val('');
				$('#estadocons').val('');
				$('#codigo').val('');
				$('#valor').val('');
				$('#doador').val('');
				$('#data_cad').val(data);

				document.getElementById("entrada").options.selectedIndex = 0;
				$('#entrada').val($('#entrada').val()).change();

				$('#target').attr('src', '../images/patrimonios/sem-foto.jpg');
			}


			


		</script>



		<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
		<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


		<style type="text/css">
			.select2-selection__rendered {
				line-height: 36px !important;
				font-size:16px !important;
				color:#666666 !important;

			}

			.select2-selection {
				height: 36px !important;
				font-size:16px !important;
				color:#666666 !important;

			}
		</style>  